import Image from "next/image"

export default function About() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="flex justify-center mb-8">
        <Image src="/logo.png" alt="Nexus Hosting Logo" width={150} height={150} className="rounded-full" />
      </div>
      <h1 className="text-4xl font-bold text-center mb-8 gradient-text">About Nexus Hosting</h1>

      <div className="grid md:grid-cols-2 gap-8">
        <AboutCard
          title="Our Mission"
          content="At Nexus Hosting, we strive to provide top-tier game server and Discord bot hosting solutions. Our goal is to empower gamers and community managers with reliable, high-performance hosting services that enhance their online experiences."
        />
        <AboutCard
          title="Our Team"
          content="We are a dedicated team of gaming enthusiasts and hosting experts. With years of experience in the industry, we understand the unique needs of gamers and Discord communities. Our team is committed to delivering exceptional service and support to ensure your hosting experience is seamless and enjoyable."
        />
        <AboutCard
          title="Our Commitment"
          content="We are committed to maintaining high standards of service quality and customer satisfaction. Our robust infrastructure and dedicated support team work tirelessly to ensure your servers stay online and perform optimally. We continuously invest in cutting-edge technology to provide you with the best hosting experience possible."
        />
        <AboutCard
          title="Our Values"
          content="Innovation, reliability, and customer-centricity are at the core of our values. We believe in transparent communication, continuous improvement, and building long-lasting relationships with our clients. Your success is our success, and we're here to support you every step of the way."
        />
      </div>
    </div>
  )
}

function AboutCard({ title, content }: { title: string; content: string }) {
  return (
    <div className="glass-card p-6 rounded-xl hover-glow transition-all duration-300">
      <h3 className="text-2xl font-semibold mb-4 gradient-text">{title}</h3>
      <p className="text-gray-300">{content}</p>
    </div>
  )
}

