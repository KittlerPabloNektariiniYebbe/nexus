"use client"

import type React from "react"

import { useState, useEffect } from "react"

interface DatabaseInfo {
  url: string
  name: string
}

interface ApiSettings {
  url: string
  key: string
}

export default function AdminDashboard() {
  const [dbInfo, setDbInfo] = useState<DatabaseInfo>({ url: "", name: "" })
  const [apiSettings, setApiSettings] = useState<ApiSettings>({ url: "", key: "" })

  useEffect(() => {
    // TODO: Fetch current database info and API settings
    setDbInfo({ url: "postgres://user:pass@host:5432/dbname", name: "production_db" })
    setApiSettings({ url: "https://api.pterodactyl.io", key: "your_api_key_here" })
  }, [])

  const handleDbInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // TODO: Update database info
    console.log("Updating database info:", dbInfo)
  }

  const handleApiSettingsSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // TODO: Update API settings
    console.log("Updating API settings:", apiSettings)
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 gradient-text">Admin Dashboard</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="glass-card p-6 rounded-xl">
          <h2 className="text-2xl font-semibold mb-4">Database Information</h2>
          <form onSubmit={handleDbInfoSubmit}>
            <div className="mb-4">
              <label htmlFor="dbUrl" className="block mb-2 text-sm font-medium text-gray-300">
                Database URL
              </label>
              <input
                type="text"
                id="dbUrl"
                value={dbInfo.url}
                onChange={(e) => setDbInfo({ ...dbInfo, url: e.target.value })}
                className="input-primary"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="dbName" className="block mb-2 text-sm font-medium text-gray-300">
                Database Name
              </label>
              <input
                type="text"
                id="dbName"
                value={dbInfo.name}
                onChange={(e) => setDbInfo({ ...dbInfo, name: e.target.value })}
                className="input-primary"
              />
            </div>
            <button type="submit" className="btn-primary">
              Update Database Info
            </button>
          </form>
        </div>
        <div className="glass-card p-6 rounded-xl">
          <h2 className="text-2xl font-semibold mb-4">API Settings</h2>
          <form onSubmit={handleApiSettingsSubmit}>
            <div className="mb-4">
              <label htmlFor="apiUrl" className="block mb-2 text-sm font-medium text-gray-300">
                API URL
              </label>
              <input
                type="text"
                id="apiUrl"
                value={apiSettings.url}
                onChange={(e) => setApiSettings({ ...apiSettings, url: e.target.value })}
                className="input-primary"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="apiKey" className="block mb-2 text-sm font-medium text-gray-300">
                API Key
              </label>
              <input
                type="password"
                id="apiKey"
                value={apiSettings.key}
                onChange={(e) => setApiSettings({ ...apiSettings, key: e.target.value })}
                className="input-primary"
              />
            </div>
            <button type="submit" className="btn-primary">
              Update API Settings
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

