"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"

export default function AdminSettings() {
  const [pterodactylSettings, setPterodactylSettings] = useState({
    PTERODACTYL_URL: "",
    PTERODACTYL_API_KEY: "",
    PTERODACTYL_EGG_ID: "",
    PTERODACTYL_DOCKER_IMAGE: "",
    PTERODACTYL_STARTUP_COMMAND: "",
  })
  const [databaseSettings, setDatabaseSettings] = useState({
    DB_HOST: "",
    DB_PORT: "",
    DB_NAME: "",
    DB_USER: "",
    DB_PASSWORD: "",
  })
  const router = useRouter()

  useEffect(() => {
    // Fetch current settings from the server
    const fetchSettings = async () => {
      try {
        const response = await fetch("/api/admin/get-settings")
        if (!response.ok) throw new Error("Failed to fetch settings")
        const data = await response.json()
        setPterodactylSettings(data.pterodactylSettings)
        setDatabaseSettings(data.databaseSettings)
      } catch (error) {
        console.error("Error fetching settings:", error)
        alert("Failed to fetch current settings")
      }
    }

    fetchSettings()
  }, [])

  const handlePterodactylSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/admin/update-pterodactyl-settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(pterodactylSettings),
      })
      if (!response.ok) throw new Error("Failed to update Pterodactyl settings")
      alert("Pterodactyl settings updated successfully")
    } catch (error) {
      console.error("Error updating Pterodactyl settings:", error)
      alert("Failed to update Pterodactyl settings")
    }
  }

  const handleDatabaseSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/admin/update-database-settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(databaseSettings),
      })
      if (!response.ok) throw new Error("Failed to update database settings")
      alert("Database settings updated successfully")
    } catch (error) {
      console.error("Error updating database settings:", error)
      alert("Failed to update database settings")
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 gradient-text">Admin Settings</h1>

      <div className="mb-12">
        <h2 className="text-2xl font-semibold mb-4">Pterodactyl Settings</h2>
        <form onSubmit={handlePterodactylSubmit} className="space-y-4">
          {Object.entries(pterodactylSettings).map(([key, value]) => (
            <div key={key}>
              <label htmlFor={key} className="block text-sm font-medium text-gray-300 mb-1">
                {key}
              </label>
              <input
                type={key.includes("API_KEY") ? "password" : "text"}
                id={key}
                value={value}
                onChange={(e) => setPterodactylSettings((prev) => ({ ...prev, [key]: e.target.value }))}
                className="input-primary"
              />
            </div>
          ))}
          <button type="submit" className="btn-primary">
            Update Pterodactyl Settings
          </button>
        </form>
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-4">Database Settings</h2>
        <form onSubmit={handleDatabaseSubmit} className="space-y-4">
          {Object.entries(databaseSettings).map(([key, value]) => (
            <div key={key}>
              <label htmlFor={key} className="block text-sm font-medium text-gray-300 mb-1">
                {key}
              </label>
              <input
                type={key === "DB_PASSWORD" ? "password" : "text"}
                id={key}
                value={value}
                onChange={(e) => setDatabaseSettings((prev) => ({ ...prev, [key]: e.target.value }))}
                className="input-primary"
              />
            </div>
          ))}
          <button type="submit" className="btn-primary">
            Update Database Settings
          </button>
        </form>
      </div>
    </div>
  )
}

