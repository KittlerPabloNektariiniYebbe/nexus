"use client"

import type React from "react"

import { useState } from "react"

export default function Contact() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically handle sending the contact form
    console.log("Contact form submitted:", { name, email, message })
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-5xl md:text-6xl font-bold mb-6 text-center gradient-text">Contact Us</h1>
      <p className="text-xl text-gray-400 mb-12 text-center max-w-3xl mx-auto">
        Have questions or need assistance? We're here to help. Reach out to us using the form below.
      </p>
      <form
        onSubmit={handleSubmit}
        className="max-w-2xl mx-auto glass-card p-8 rounded-xl hover-glow transition-all duration-300"
      >
        <div className="mb-6">
          <label htmlFor="name" className="block mb-2 text-lg font-semibold text-gray-300">
            Name
          </label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-[#FF3E3E] transition-colors text-white"
            required
          />
        </div>
        <div className="mb-6">
          <label htmlFor="email" className="block mb-2 text-lg font-semibold text-gray-300">
            Email
          </label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-[#FF3E3E] transition-colors text-white"
            required
          />
        </div>
        <div className="mb-6">
          <label htmlFor="message" className="block mb-2 text-lg font-semibold text-gray-300">
            Message
          </label>
          <textarea
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-[#FF3E3E] transition-colors text-white"
            rows={4}
            required
          ></textarea>
        </div>
        <button
          type="submit"
          className="w-full bg-gradient-to-r from-[#FF3E3E] to-[#FF6B6B] text-white px-6 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
        >
          Send Message
        </button>
      </form>
    </div>
  )
}

