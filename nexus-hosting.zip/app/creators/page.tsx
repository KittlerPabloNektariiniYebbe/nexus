const creators = [
  { name: "John Doe", role: "Founder & CEO", bio: "Passionate about game server technology." },
  { name: "Jane Smith", role: "CTO", bio: "Expert in Discord bot development and hosting." },
  { name: "Mike Johnson", role: "Lead Developer", bio: "Full-stack developer with a focus on scalability." },
  { name: "Sarah Brown", role: "Customer Support Manager", bio: "Dedicated to providing excellent customer service." },
]

export default function Creators() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-5xl font-bold mb-12 text-center">Our Team</h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {creators.map((creator, index) => (
          <div
            key={index}
            className="bg-secondary p-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300"
          >
            <h2 className="text-2xl font-semibold mb-2 text-primary">{creator.name}</h2>
            <p className="text-text-secondary mb-2">{creator.role}</p>
            <p className="text-text-secondary">{creator.bio}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

