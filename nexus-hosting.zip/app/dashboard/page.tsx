"use client"

import { useState, useEffect } from "react"
import Link from "next/link"

interface Server {
  id: string
  name: string
  status: "online" | "offline"
}

export default function Dashboard() {
  const [servers, setServers] = useState<Server[]>([])

  useEffect(() => {
    // TODO: Fetch user's servers from API
    setServers([
      { id: "1", name: "Minecraft Server", status: "online" },
      { id: "2", name: "Discord Bot", status: "offline" },
    ])
  }, [])

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 gradient-text">Dashboard</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="glass-card p-6 rounded-xl">
          <h2 className="text-2xl font-semibold mb-4">Your Servers</h2>
          {servers.map((server) => (
            <div key={server.id} className="flex justify-between items-center mb-4">
              <span>{server.name}</span>
              <span className={`px-2 py-1 rounded ${server.status === "online" ? "bg-green-500" : "bg-red-500"}`}>
                {server.status}
              </span>
            </div>
          ))}
          <Link href="/create-server" className="btn-primary inline-block mt-4">
            Create New Server
          </Link>
        </div>
        <div className="glass-card p-6 rounded-xl">
          <h2 className="text-2xl font-semibold mb-4">Quick Actions</h2>
          <ul className="space-y-2">
            <li>
              <Link href="/billing" className="text-blue-400 hover:underline">
                Manage Billing
              </Link>
            </li>
            <li>
              <Link href="/support" className="text-blue-400 hover:underline">
                Contact Support
              </Link>
            </li>
            <li>
              <Link href="/settings" className="text-blue-400 hover:underline">
                Account Settings
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}

