import type React from "react"
import { Shield, Cpu, Gauge, Server, Cloud, Clock, Headphones, Zap } from "lucide-react"

export default function Features() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-5xl md:text-6xl font-bold mb-6 text-center gradient-text">Our Features</h1>
      <p className="text-xl text-gray-300 mb-12 text-center max-w-3xl mx-auto">
        Experience unparalleled performance and reliability with our cutting-edge hosting features
      </p>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <FeatureCard
          icon={<Shield className="w-10 h-10" />}
          title="Advanced DDoS Protection"
          description="Multi-layered protection with up to 12 Tbps mitigation"
        />
        <FeatureCard
          icon={<Cpu className="w-10 h-10" />}
          title="High-Performance CPUs"
          description="Powered by the latest AMD EPYC processors"
        />
        <FeatureCard
          icon={<Gauge className="w-10 h-10" />}
          title="NVMe SSD Storage"
          description="Lightning-fast storage for optimal performance"
        />
        <FeatureCard
          icon={<Server className="w-10 h-10" />}
          title="Intuitive Control Panel"
          description="Easy-to-use panel for effortless management"
        />
        <FeatureCard
          icon={<Cloud className="w-10 h-10" />}
          title="Global Network"
          description="Low-latency connections worldwide"
        />
        <FeatureCard
          icon={<Clock className="w-10 h-10" />}
          title="99.9% Uptime Guarantee"
          description="Reliable hosting you can count on"
        />
        <FeatureCard
          icon={<Headphones className="w-10 h-10" />}
          title="24/7 Expert Support"
          description="Round-the-clock professional assistance"
        />
        <FeatureCard
          icon={<Zap className="w-10 h-10" />}
          title="Instant Setup"
          description="Get your server running in minutes"
        />
      </div>
    </div>
  )
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <div className="glass-card p-6 rounded-xl hover-glow transition-all duration-300 flex items-start">
      <div className="text-[#FF3E3E] mr-4 flex-shrink-0">{icon}</div>
      <div>
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-gray-400 text-sm">{description}</p>
      </div>
    </div>
  )
}

