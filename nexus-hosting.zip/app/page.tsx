import type React from "react"
import Link from "next/link"
import { Shield, Cpu, Gauge, Server } from "lucide-react"

export default function Home() {
  return (
    <div className="container mx-auto px-4">
      <section className="py-16 text-center">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 gradient-text">Premium Game Server Hosting</h1>
        <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
          Experience unparalleled performance and security with our hosting solutions
        </p>
        <Link href="/products" className="btn-primary text-lg">
          Get Started
        </Link>
      </section>

      <section className="py-16">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 gradient-text">Our Features</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <FeatureCard
            icon={<Shield className="w-8 h-8" />}
            title="DDoS Protection"
            description="Multi-layered protection with up to 12 Tbps mitigation"
          />
          <FeatureCard
            icon={<Cpu className="w-8 h-8" />}
            title="AMD EPYC CPUs"
            description="High-performance processors for smooth gameplay"
          />
          <FeatureCard
            icon={<Gauge className="w-8 h-8" />}
            title="NVMe SSDs"
            description="Lightning-fast storage for optimal game performance"
          />
          <FeatureCard
            icon={<Server className="w-8 h-8" />}
            title="Control Panel"
            description="Powerful and intuitive control panel for your servers"
          />
        </div>
      </section>
    </div>
  )
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <div className="glass-card p-6 rounded-xl hover-glow transition-all duration-300">
      <div className="text-[#FF3E3E] mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  )
}

