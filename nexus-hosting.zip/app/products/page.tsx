import Link from "next/link"

const products = [
  { name: "Basic Game Server", price: "$9.99/mo", description: "Perfect for small communities" },
  { name: "Pro Game Server", price: "$19.99/mo", description: "Ideal for medium-sized gaming groups" },
  { name: "Enterprise Game Server", price: "$49.99/mo", description: "For large gaming communities" },
  { name: "Basic Discord Bot", price: "$4.99/mo", description: "Host a simple Discord bot" },
  { name: "Advanced Discord Bot", price: "$9.99/mo", description: "For complex Discord bots with high uptime" },
]

export default function Products() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-5xl font-bold mb-12 text-center">Our Products</h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {products.map((product, index) => (
          <div
            key={index}
            className="bg-secondary p-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300"
          >
            <h2 className="text-2xl font-semibold mb-2 text-primary">{product.name}</h2>
            <p className="text-text-secondary mb-4">{product.description}</p>
            <p className="text-3xl font-bold mb-6">{product.price}</p>
            <Link
              href="/contact"
              className="bg-primary text-text px-6 py-3 rounded-full hover:bg-primary/80 transition-colors inline-block"
            >
              Order Now
            </Link>
          </div>
        ))}
      </div>
    </div>
  )
}

