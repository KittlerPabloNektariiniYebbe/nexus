import type React from "react"
import Link from "next/link"
import { MessageCircle, FileText, PhoneCall, Mail } from "lucide-react"

export default function Support() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-5xl md:text-6xl font-bold mb-6 text-center gradient-text">Support Center</h1>
      <p className="text-xl text-gray-400 mb-12 text-center max-w-3xl mx-auto">
        We're here to help. Choose from our range of support options to get the assistance you need.
      </p>

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        <SupportCard
          icon={<MessageCircle className="w-12 h-12" />}
          title="Live Chat"
          description="Get instant help from our support team through our live chat service."
          link="/live-chat"
          linkText="Start Chat"
        />
        <SupportCard
          icon={<FileText className="w-12 h-12" />}
          title="Knowledge Base"
          description="Find answers to common questions in our comprehensive knowledge base."
          link="/knowledge-base"
          linkText="Browse Articles"
        />
        <SupportCard
          icon={<PhoneCall className="w-12 h-12" />}
          title="Phone Support"
          description="Speak directly with our support team for more complex issues."
          link="tel:+1234567890"
          linkText="Call Us"
        />
        <SupportCard
          icon={<Mail className="w-12 h-12" />}
          title="Email Support"
          description="Send us an email and we'll get back to you as soon as possible."
          link="mailto:support@nexushosting.com"
          linkText="Email Us"
        />
      </div>

      <div className="glass-card p-8 rounded-xl hover-glow transition-all duration-300 text-center">
        <h2 className="text-3xl font-bold mb-4">Need Immediate Assistance?</h2>
        <p className="text-gray-400 mb-6">
          Our support team is available 24/7 to help you with any issues or questions.
        </p>
        <Link
          href="/tickets/new"
          className="inline-block px-8 py-4 rounded-lg bg-gradient-to-r from-[#FF3E3E] to-[#FF6B6B] text-lg font-semibold hover:opacity-90 transition-opacity"
        >
          Open a Support Ticket
        </Link>
      </div>
    </div>
  )
}

function SupportCard({
  icon,
  title,
  description,
  link,
  linkText,
}: {
  icon: React.ReactNode
  title: string
  description: string
  link: string
  linkText: string
}) {
  return (
    <div className="glass-card p-8 rounded-xl hover-glow transition-all duration-300">
      <div className="text-[#FF3E3E] mb-6">{icon}</div>
      <h3 className="text-2xl font-semibold mb-4">{title}</h3>
      <p className="text-gray-400 mb-6">{description}</p>
      <Link
        href={link}
        className="inline-block px-6 py-2 rounded-lg bg-gradient-to-r from-[#FF3E3E] to-[#FF6B6B] text-sm font-semibold hover:opacity-90 transition-opacity"
      >
        {linkText}
      </Link>
    </div>
  )
}

