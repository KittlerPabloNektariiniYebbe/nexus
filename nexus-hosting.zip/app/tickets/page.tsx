"use client"

import type React from "react"

import { useState } from "react"

export default function Tickets() {
  const [subject, setSubject] = useState("")
  const [description, setDescription] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically handle creating a new support ticket
    console.log("New ticket submitted:", { subject, description })
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-5xl font-bold mb-12 text-center">Support Tickets</h1>
      <form onSubmit={handleSubmit} className="max-w-md mx-auto bg-secondary p-8 rounded-lg shadow-lg">
        <div className="mb-6">
          <label htmlFor="subject" className="block mb-2 text-text-secondary">
            Subject
          </label>
          <input
            type="text"
            id="subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="w-full p-3 bg-background border border-gray-600 rounded focus:outline-none focus:border-primary transition-colors"
            required
          />
        </div>
        <div className="mb-6">
          <label htmlFor="description" className="block mb-2 text-text-secondary">
            Description
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-3 bg-background border border-gray-600 rounded focus:outline-none focus:border-primary transition-colors"
            rows={4}
            required
          ></textarea>
        </div>
        <button
          type="submit"
          className="w-full bg-primary text-text px-6 py-3 rounded-full hover:bg-primary/80 transition-colors"
        >
          Submit Ticket
        </button>
      </form>
    </div>
  )
}

