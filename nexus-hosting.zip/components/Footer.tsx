import Link from "next/link"

export default function Footer() {
  return (
    <footer className="nav-blur py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold gradient-text mb-4">Nexus Hosting</h3>
            <p className="text-gray-400">Premium game server and Discord bot hosting solutions</p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Products</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/game-servers" className="text-gray-400 hover:text-white">
                  Game Servers
                </Link>
              </li>
              <li>
                <Link href="/discord-bots" className="text-gray-400 hover:text-white">
                  Discord Bots
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/tickets" className="text-gray-400 hover:text-white">
                  Support Tickets
                </Link>
              </li>
              <li>
                <Link href="/knowledge-base" className="text-gray-400 hover:text-white">
                  Knowledge Base
                </Link>
              </li>
              <li>
                <Link href="https://status.nexushosting.xyz" className="text-gray-400 hover:text-white">
                  Server Status
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-gray-400 hover:text-white">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-white">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/careers" className="text-gray-400 hover:text-white">
                  Careers
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Nexus Hosting. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

