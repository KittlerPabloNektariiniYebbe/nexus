"use client"

import type React from "react"

import Link from "next/link"
import { useState } from "react"
import { Menu, X } from "lucide-react"

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="fixed w-full z-50 nav-blur">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold gradient-text">
            Nexus Hosting
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <NavLink href="/products">Products</NavLink>
            <NavLink href="/features">Features</NavLink>
            <NavLink href="/support">Support</NavLink>
            <NavLink href="/about">About</NavLink>
            <NavLink href="/admin/settings">Admin</NavLink>
            <Link href="/login" className="btn-primary">
              Login
            </Link>
          </div>

          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isOpen && (
          <div className="md:hidden mt-4 space-y-4">
            <NavLink href="/products">Products</NavLink>
            <NavLink href="/features">Features</NavLink>
            <NavLink href="/support">Support</NavLink>
            <NavLink href="/about">About</NavLink>
            <NavLink href="/admin/settings">Admin</NavLink>
            <Link href="/login" className="block btn-primary text-center">
              Login
            </Link>
          </div>
        )}
      </div>
    </nav>
  )
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="text-gray-300 hover:text-white transition-colors">
      {children}
    </Link>
  )
}

