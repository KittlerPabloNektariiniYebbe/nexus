import type { NextApiRequest, NextApiResponse } from "next"
import jwt from "jsonwebtoken"
import { PrismaClient, type User } from "@prisma/client"

const prisma = new PrismaClient()

const JWT_SECRET = process.env.JWT_SECRET

if (!JWT_SECRET) {
  console.error("Missing JWT_SECRET environment variable")
  throw new Error("Missing JWT_SECRET environment variable")
}

export function generateToken(user: User) {
  return jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "1d" })
}

export async function authenticateUser(req: NextApiRequest, res: NextApiResponse) {
  const token = req.headers.authorization?.split(" ")[1]
  if (!token) {
    res.status(401).json({ error: "Authentication required" })
    return null
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string }
    const user = await prisma.user.findUnique({ where: { id: decoded.userId } })
    if (!user) {
      res.status(401).json({ error: "User not found" })
      return null
    }
    return user
  } catch (error) {
    res.status(401).json({ error: "Invalid token" })
    return null
  }
}

