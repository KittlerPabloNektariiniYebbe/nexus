import axios from "axios"

const PTERODACTYL_URL = process.env.PTERODACTYL_URL
const PTERODACTYL_API_KEY = process.env.PTERODACTYL_API_KEY
const PTERODACTYL_EGG_ID = process.env.PTERODACTYL_EGG_ID
const PTERODACTYL_DOCKER_IMAGE = process.env.PTERODACTYL_DOCKER_IMAGE
const PTERODACTYL_STARTUP_COMMAND = process.env.PTERODACTYL_STARTUP_COMMAND

if (
  !PTERODACTYL_URL ||
  !PTERODACTYL_API_KEY ||
  !PTERODACTYL_EGG_ID ||
  !PTERODACTYL_DOCKER_IMAGE ||
  !PTERODACTYL_STARTUP_COMMAND
) {
  console.error("Missing Pterodactyl environment variables")
  throw new Error("Missing Pterodactyl environment variables")
}

const pterodactylApi = axios.create({
  baseURL: PTERODACTYL_URL,
  headers: {
    Authorization: `Bearer ${PTERODACTYL_API_KEY}`,
    "Content-Type": "application/json",
    Accept: "Application/vnd.pterodactyl.v1+json",
  },
})

export async function createServer(name: string, userId: string) {
  try {
    const response = await pterodactylApi.post("/api/application/servers", {
      name,
      user: userId,
      egg: Number.parseInt(PTERODACTYL_EGG_ID),
      docker_image: PTERODACTYL_DOCKER_IMAGE,
      startup: PTERODACTYL_STARTUP_COMMAND,
      environment: {
        STARTUP: PTERODACTYL_STARTUP_COMMAND,
        SERVER_JARFILE: "server.jar",
      },
      limits: {
        memory: 1024,
        swap: 0,
        disk: 5120,
        io: 500,
        cpu: 100,
      },
      feature_limits: {
        databases: 1,
        allocations: 1,
        backups: 1,
      },
      deploy: {
        locations: [1],
        dedicated_ip: false,
        port_range: [],
      },
    })

    return response.data.attributes
  } catch (error) {
    console.error("Error creating server:", error)
    throw error
  }
}

